from mesa import Model
from mesa.time import BaseScheduler
from mesa.datacollection import DataCollector
import re

# Importar los agentes desde el archivo agentes.py
from agentes import SumaAgente, RestaAgente, MultiplicacionAgente, DivisionAgente, PotenciaAgente

class CalculadoraModel(Model):
    """Modelo para la calculadora basada en el paradigma de agentes."""

    def __init__(self):
        """Inicializa el modelo de la calculadora y los agentes."""
        self.schedule = BaseScheduler(self)
        
        # Crear los agentes y agregarlos al scheduler
        self.suma_agente = SumaAgente(1, self)
        self.resta_agente = RestaAgente(2, self)
        self.mult_agente = MultiplicacionAgente(3, self)
        self.division_agente = DivisionAgente(4, self)
        self.potencia_agente = PotenciaAgente(5, self)

        # Agregar los agentes al scheduler
        self.schedule.add(self.suma_agente)
        self.schedule.add(self.resta_agente)
        self.schedule.add(self.mult_agente)
        self.schedule.add(self.division_agente)
        self.schedule.add(self.potencia_agente)

        # DataCollector (opcional, puedes usarlo si deseas hacer seguimiento de resultados)
        self.datacollector = DataCollector(
            agent_reporters={"Resultado": "resultado"}
        )

    def step(self):
        """Realiza un paso en el modelo."""
        self.schedule.step()

    def resolver_expresion(self, expresion):
        """Resuelve una expresión matemática y devuelve el resultado."""
        # Tokenizar la expresión
        tokens = self.tokenizar_expresion(expresion)
        
        # Evaluar la expresión
        resultado = self.evaluar_tokens(tokens)
        return resultado

    def tokenizar_expresion(self, expresion):
        """Divide la expresión en números y operadores."""
        return re.findall(r'\d+|[+*/()-]', expresion)

    def evaluar_tokens(self, tokens):
        """Evalúa la expresión basada en los tokens, manejando la precedencia de operadores."""
        salida = []
        operadores = []
        
        # Diccionario para la precedencia de operadores
        precedencia = {'+': 1, '-': 1, '*': 2, '/': 2, '**': 3}

        def aplicar_operacion(operador, b, a):
            if operador == '+':
                return self.suma_agente.calcular(a, b)
            elif operador == '-':
                return self.resta_agente.calcular(a, b)
            elif operador == '*':
                return self.mult_agente.calcular(a, b)
            elif operador == '/':
                return self.division_agente.calcular(a, b)
            elif operador == '**':
                return self.potencia_agente.calcular(a, b)

        for token in tokens:
            if token.isdigit():
                salida.append(int(token))
            elif token in precedencia:
                while (operadores and
                       precedencia[operadores[-1]] >= precedencia[token]):
                    op = operadores.pop()
                    b = salida.pop()
                    a = salida.pop()
                    resultado = aplicar_operacion(op, b, a)
                    salida.append(resultado)
                operadores.append(token)

        while operadores:
            op = operadores.pop()
            b = salida.pop()
            a = salida.pop()
            resultado = aplicar_operacion(op, b, a)
            salida.append(resultado)

        return salida[0] if salida else None
