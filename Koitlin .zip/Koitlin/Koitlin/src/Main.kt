import java.lang.Math.toRadians
import java.util.*
import kotlin.math.*

class CalculadoraCientifica {
    private var memoria: Double = 0.0

    fun evaluarExpresion(expresion: String): Double {
        val tokens = convertirAPostfix(expresion)
        return evaluarPostfix(tokens)
    }

    fun guardarEnMemoria(valor: Double) { memoria = valor }
    fun recuperarDeMemoria(): Double = memoria
    fun limpiarMemoria() { memoria = 0.0 }
    fun sumarMemoria(valor: Double) { memoria += valor }
    fun restarMemoria(valor: Double) { memoria -= valor }

    private fun convertirAPostfix(expresion: String): List<String> {
        val operadores = Stack<String>()
        val resultado = mutableListOf<String>()
        val tokens = Regex("""\d+(\.\d+)?|[-+*/^()]|sin|cos|tan|log|sqrt""").findAll(expresion.replace("\\s+".toRegex(), "")).map { it.value }

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> resultado.add(token)
                token in listOf("sin", "cos", "tan", "log", "sqrt") -> operadores.push(token)
                token == "(" -> operadores.push(token)
                token == ")" -> {
                    while (operadores.isNotEmpty() && operadores.peek() != "(") {
                        resultado.add(operadores.pop())
                    }
                    if (operadores.isNotEmpty() && operadores.peek() == "(") {
                        operadores.pop()
                    }
                    if (operadores.isNotEmpty() && operadores.peek() in listOf("sin", "cos", "tan", "log", "sqrt")) {
                        resultado.add(operadores.pop())
                    }
                }
                token in listOf("+", "-", "*", "/", "^") -> {
                    while (operadores.isNotEmpty() && precedencia(operadores.peek()) >= precedencia(token)) {
                        resultado.add(operadores.pop())
                    }
                    operadores.push(token)
                }
            }
        }

        while (operadores.isNotEmpty()) {
            resultado.add(operadores.pop())
        }
        return resultado
    }

    private fun evaluarPostfix(tokens: List<String>): Double {
        val stack = Stack<Double>()
        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> stack.push(token.toDouble())
                token in listOf("+", "-", "*", "/", "^") -> {
                    val b = stack.pop()
                    val a = stack.pop()
                    stack.push(realizarOperacion(a, b, token))
                }
                token in listOf("sin", "cos", "tan", "log", "sqrt") -> {
                    val a = stack.pop()
                    stack.push(realizarFuncion(a, token))
                }
            }
        }
        return stack.pop()
    }

    private fun realizarOperacion(a: Double, b: Double, operador: String): Double {
        return when (operador) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b != 0.0) a / b else throw IllegalArgumentException("No se puede dividir entre cero")
            "^" -> a.pow(b)
            else -> throw IllegalArgumentException("Operador no válido: $operador")
        }
    }

    private fun realizarFuncion(a: Double, funcion: String): Double {
        return when (funcion) {
            "sin" -> sin(toRadians(a))
            "cos" -> cos(toRadians(a))
            "tan" -> tan(toRadians(a))
            "log" -> if (a > 0) log10(a) else throw IllegalArgumentException("Logaritmo no definido para valores <= 0")
            "sqrt" -> if (a >= 0) sqrt(a) else throw IllegalArgumentException("Raíz no definida para valores negativos")
            else -> throw IllegalArgumentException("Función no válida: $funcion")
        }
    }

    private fun precedencia(operador: String): Int {
        return when (operador) {
            "+", "-" -> 1
            "*", "/" -> 2
            "^" -> 3
            else -> 0
        }
    }
}

fun main() {
    val calc = CalculadoraCientifica()
    val scanner = Scanner(System.`in`)

    println("Introduce la expresión que deseas evaluar (ejemplo: '2 + 3 * sin(45) - log(10)'):")
    val input = scanner.nextLine()

    try {
        val resultado = calc.evaluarExpresion(input)
        println("Resultado: $resultado")
    } catch (e: Exception) {
        println("Error: ${e.message}")
    } finally {
        scanner.close()
    }
}
