import java.lang.Math.pow
import java.lang.Math.toRadians
import kotlin.math.*

open class Calculadora {
    fun suma(a: Double, b: Double): Double = a + b
    fun resta(a: Double, b: Double): Double = a - b
    fun multiplicacion(a: Double, b: Double): Double = a * b
    fun division(a: Double, b: Double): Double {
        if (b == 0.0) throw IllegalArgumentException("No se puede dividir entre cero")
        return a / b
    }
}

class CalculadoraCientifica : Calculadora() {
    private var memoria: Double = 0.0


    fun seno(x: Double): Double = sin(x)
    fun coseno(x: Double): Double = cos(x)
    fun tangente(x: Double): Double = tan(x)

    fun potencia(base: Double, exponente: Double): Double = pow(base, exponente)

    fun raiz(x: Double): Double {
        if (x < 0) throw IllegalArgumentException("No se puede calcular la raíz de un número negativo")
        return sqrt(x)
    }

    // Logaritmo base 10
    fun logaritmo(x: Double): Double {
        if (x <= 0) throw IllegalArgumentException("El logaritmo no está definido para valores <= 0")
        return log10(x)
    }


    fun guardarEnMemoria(valor: Double) { memoria = valor }
    fun recuperarDeMemoria(): Double = memoria
    fun limpiarMemoria() { memoria = 0.0 }
}

fun main() {
    val calc = CalculadoraCientifica()

    //pruebas
    println("Suma: ${calc.suma(3.0, 4.0)}")


    println("Coseno de 45 grados: ${calc.coseno(toRadians(45.0))}")
    println("Potencia 2^3: ${calc.potencia(2.0, 3.0)}")
    println("Raíz cuadrada de 16: ${calc.raiz(16.0)}")
    println("Logaritmo de 1000: ${calc.logaritmo(1000.0)}")

    calc.guardarEnMemoria(25.0)
    println("Valor guardado en memoria: ${calc.recuperarDeMemoria()}")
    calc.limpiarMemoria()
    println("Memoria después de limpiar: ${calc.recuperarDeMemoria()}")
}
